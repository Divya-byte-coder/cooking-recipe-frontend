import { useParams, Link } from 'react-router-dom';
import { useRecipes } from './RecipeContext';
import { Clock, Users, ChefHat, ArrowLeft, Timer } from 'lucide-react';

export function RecipeDetail() {
  const { id } = useParams<{ id: string }>();
  const { getRecipeById } = useRecipes();

  const recipe = id ? getRecipeById(id) : undefined;

  if (!recipe) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center">
          <h2 className="text-2xl text-gray-900 mb-4">Recipe not found</h2>
          <Link to="/" className="text-orange-600 hover:text-orange-700">
            Return to home
          </Link>
        </div>
      </div>
    );
  }

  const totalTime = recipe.prepTime + recipe.cookTime;

  const difficultyColors = {
    Easy: 'bg-green-100 text-green-700',
    Medium: 'bg-yellow-100 text-yellow-700',
    Hard: 'bg-red-100 text-red-700'
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Back Button */}
      <Link 
        to="/" 
        className="inline-flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
      >
        <ArrowLeft className="w-5 h-5" />
        Back to recipes
      </Link>

      {/* Recipe Header */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden mb-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="relative aspect-[4/3] lg:aspect-auto">
            <img
              src={recipe.image}
              alt={recipe.title}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="p-8">
            <div className="flex items-center gap-2 mb-3">
              <span className="px-3 py-1 bg-orange-50 text-orange-600 rounded-lg">
                {recipe.category}
              </span>
              <span className={`px-3 py-1 rounded-lg ${difficultyColors[recipe.difficulty]}`}>
                {recipe.difficulty}
              </span>
            </div>

            <h1 className="text-4xl text-gray-900 mb-4">{recipe.title}</h1>
            <p className="text-lg text-gray-600 mb-6">{recipe.description}</p>

            <div className="flex items-center gap-2 text-gray-600 mb-8">
              <ChefHat className="w-5 h-5 text-orange-500" />
              <span>By {recipe.author}</span>
              <span className="text-gray-400">•</span>
              <span>{recipe.createdAt}</span>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="bg-gray-50 p-4 rounded-lg text-center">
                <Clock className="w-6 h-6 mx-auto mb-2 text-gray-600" />
                <div className="text-2xl text-gray-900">{totalTime}</div>
                <div className="text-sm text-gray-600">Total Time</div>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg text-center">
                <Timer className="w-6 h-6 mx-auto mb-2 text-gray-600" />
                <div className="text-2xl text-gray-900">{recipe.prepTime}</div>
                <div className="text-sm text-gray-600">Prep Time</div>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg text-center">
                <Users className="w-6 h-6 mx-auto mb-2 text-gray-600" />
                <div className="text-2xl text-gray-900">{recipe.servings}</div>
                <div className="text-sm text-gray-600">Servings</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Ingredients and Instructions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Ingredients */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 sticky top-24">
            <h2 className="text-2xl text-gray-900 mb-4">Ingredients</h2>
            <ul className="space-y-3">
              {recipe.ingredients.map((ingredient, index) => (
                <li key={index} className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 flex-shrink-0" />
                  <span className="text-gray-700">{ingredient}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Instructions */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h2 className="text-2xl text-gray-900 mb-6">Instructions</h2>
            <ol className="space-y-6">
              {recipe.instructions.map((instruction, index) => (
                <li key={index} className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-orange-500 text-white rounded-full flex items-center justify-center">
                    {index + 1}
                  </div>
                  <p className="text-gray-700 pt-1">{instruction}</p>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
}
