import { useRecipes } from './RecipeContext';
import { RecipeCard } from './RecipeCard';
import { Clock, Users, Search } from 'lucide-react';
import { useState } from 'react';

export function HomePage() {
  const { recipes } = useRecipes();
  const [searchQuery, setSearchQuery] = useState('');

  const featuredRecipes = recipes.slice(0, 3);
  const recentRecipes = recipes.slice(0, 6);

  const filteredRecipes = searchQuery
    ? recipes.filter(recipe =>
        recipe.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        recipe.category.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : recentRecipes;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-orange-500 to-red-500 rounded-2xl p-12 mb-12 text-white">
        <h1 className="text-5xl mb-4">Discover & Share Amazing Recipes</h1>
        <p className="text-xl mb-8 text-orange-50">
          Explore thousands of delicious recipes from home cooks around the world
        </p>
        
        <div className="relative max-w-2xl">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search for recipes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-4 rounded-lg text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-orange-300"
          />
        </div>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center gap-4">
            <div className="bg-orange-100 p-3 rounded-lg">
              <BookOpen className="w-6 h-6 text-orange-600" />
            </div>
            <div>
              <div className="text-3xl text-gray-900">{recipes.length}</div>
              <div className="text-gray-600">Total Recipes</div>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center gap-4">
            <div className="bg-blue-100 p-3 rounded-lg">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <div className="text-3xl text-gray-900">12K+</div>
              <div className="text-gray-600">Home Cooks</div>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center gap-4">
            <div className="bg-green-100 p-3 rounded-lg">
              <Clock className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <div className="text-3xl text-gray-900">15min</div>
              <div className="text-gray-600">Avg. Prep Time</div>
            </div>
          </div>
        </div>
      </div>

      {/* Featured Recipes */}
      {!searchQuery && (
        <section className="mb-12">
          <h2 className="text-3xl text-gray-900 mb-6">Featured Recipes</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {featuredRecipes.map(recipe => (
              <RecipeCard key={recipe.id} recipe={recipe} featured />
            ))}
          </div>
        </section>
      )}

      {/* Recent/Search Results */}
      <section>
        <h2 className="text-3xl text-gray-900 mb-6">
          {searchQuery ? 'Search Results' : 'Recent Recipes'}
        </h2>
        {filteredRecipes.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredRecipes.map(recipe => (
              <RecipeCard key={recipe.id} recipe={recipe} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 text-gray-500">
            No recipes found matching your search.
          </div>
        )}
      </section>
    </div>
  );
}

import { BookOpen } from 'lucide-react';
