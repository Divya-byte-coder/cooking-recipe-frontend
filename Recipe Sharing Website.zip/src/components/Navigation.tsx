import { Link, useLocation } from 'react-router-dom';
import { ChefHat, Home, BookOpen, Plus } from 'lucide-react';

export function Navigation() {
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center gap-2">
            <ChefHat className="w-8 h-8 text-orange-500" />
            <span className="text-xl text-gray-900">RecipeShare</span>
          </Link>

          <div className="flex gap-6">
            <Link
              to="/"
              className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-colors ${
                isActive('/') 
                  ? 'bg-orange-50 text-orange-600' 
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <Home className="w-5 h-5" />
              <span>Home</span>
            </Link>

            <Link
              to="/browse"
              className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-colors ${
                isActive('/browse') 
                  ? 'bg-orange-50 text-orange-600' 
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <BookOpen className="w-5 h-5" />
              <span>Browse</span>
            </Link>

            <Link
              to="/add"
              className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-colors ${
                isActive('/add') 
                  ? 'bg-orange-50 text-orange-600' 
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <Plus className="w-5 h-5" />
              <span>Add Recipe</span>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}
