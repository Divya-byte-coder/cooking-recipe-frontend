import { createContext, useContext, useState, ReactNode } from 'react';

export interface Recipe {
  id: string;
  title: string;
  description: string;
  image: string;
  prepTime: number;
  cookTime: number;
  servings: number;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  category: string;
  ingredients: string[];
  instructions: string[];
  author: string;
  createdAt: string;
}

interface RecipeContextType {
  recipes: Recipe[];
  addRecipe: (recipe: Omit<Recipe, 'id' | 'createdAt'>) => void;
  getRecipeById: (id: string) => Recipe | undefined;
}

const RecipeContext = createContext<RecipeContextType | undefined>(undefined);

const initialRecipes: Recipe[] = [
  {
    id: '1',
    title: 'Classic Margherita Pizza',
    description: 'A simple yet delicious Italian pizza with fresh mozzarella, tomatoes, and basil.',
    image: 'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=800&q=80',
    prepTime: 20,
    cookTime: 15,
    servings: 4,
    difficulty: 'Medium',
    category: 'Italian',
    ingredients: [
      '2 cups all-purpose flour',
      '1 tsp instant yeast',
      '1 tsp salt',
      '3/4 cup warm water',
      '2 tbsp olive oil',
      '1 cup tomato sauce',
      '8 oz fresh mozzarella',
      'Fresh basil leaves',
      'Salt and pepper to taste'
    ],
    instructions: [
      'Mix flour, yeast, and salt in a large bowl.',
      'Add warm water and olive oil, mix until dough forms.',
      'Knead for 10 minutes until smooth and elastic.',
      'Let rise for 1 hour in a warm place.',
      'Preheat oven to 475°F (245°C).',
      'Roll out dough into a 12-inch circle.',
      'Spread tomato sauce evenly, leaving a 1-inch border.',
      'Top with torn mozzarella and bake for 12-15 minutes.',
      'Garnish with fresh basil before serving.'
    ],
    author: 'Maria Rossi',
    createdAt: '2024-12-01'
  },
  {
    id: '2',
    title: 'Thai Green Curry',
    description: 'Aromatic and spicy Thai curry with vegetables and coconut milk.',
    image: 'https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=800&q=80',
    prepTime: 15,
    cookTime: 25,
    servings: 4,
    difficulty: 'Easy',
    category: 'Thai',
    ingredients: [
      '2 tbsp green curry paste',
      '1 can coconut milk',
      '2 cups mixed vegetables',
      '1 lb chicken breast, cubed',
      '2 tbsp fish sauce',
      '1 tbsp brown sugar',
      'Fresh basil leaves',
      'Lime wedges for serving'
    ],
    instructions: [
      'Heat oil in a large pan over medium heat.',
      'Add curry paste and cook for 1 minute until fragrant.',
      'Pour in half the coconut milk and stir well.',
      'Add chicken and cook until no longer pink.',
      'Add vegetables and remaining coconut milk.',
      'Season with fish sauce and brown sugar.',
      'Simmer for 15 minutes until vegetables are tender.',
      'Garnish with basil and serve with lime wedges.'
    ],
    author: 'Somchai Chen',
    createdAt: '2024-12-03'
  },
  {
    id: '3',
    title: 'Chocolate Lava Cake',
    description: 'Decadent molten chocolate cake with a gooey center.',
    image: 'https://images.unsplash.com/photo-1624353365286-3f8d62daad51?w=800&q=80',
    prepTime: 15,
    cookTime: 12,
    servings: 4,
    difficulty: 'Medium',
    category: 'Dessert',
    ingredients: [
      '4 oz dark chocolate',
      '1/2 cup butter',
      '2 eggs',
      '2 egg yolks',
      '1/4 cup sugar',
      '2 tbsp flour',
      'Butter for greasing',
      'Cocoa powder for dusting'
    ],
    instructions: [
      'Preheat oven to 425°F (220°C).',
      'Grease 4 ramekins with butter and dust with cocoa powder.',
      'Melt chocolate and butter together.',
      'Whisk eggs, egg yolks, and sugar until thick.',
      'Fold in melted chocolate mixture.',
      'Sift in flour and fold gently.',
      'Divide batter among ramekins.',
      'Bake for 12 minutes until edges are firm but center is soft.',
      'Let cool for 1 minute, then invert onto plates.'
    ],
    author: 'Pierre Dubois',
    createdAt: '2024-12-05'
  },
  {
    id: '4',
    title: 'Caesar Salad',
    description: 'Crisp romaine lettuce with creamy Caesar dressing and parmesan.',
    image: 'https://images.unsplash.com/photo-1546793665-c74683f339c1?w=800&q=80',
    prepTime: 15,
    cookTime: 0,
    servings: 4,
    difficulty: 'Easy',
    category: 'Salad',
    ingredients: [
      '1 large head romaine lettuce',
      '1/2 cup mayonnaise',
      '2 tbsp lemon juice',
      '2 cloves garlic, minced',
      '2 tsp Dijon mustard',
      '1/2 cup grated Parmesan',
      '2 cups croutons',
      'Salt and pepper to taste'
    ],
    instructions: [
      'Wash and chop romaine lettuce into bite-sized pieces.',
      'In a bowl, mix mayonnaise, lemon juice, garlic, and mustard.',
      'Add half the Parmesan cheese to the dressing.',
      'Season with salt and pepper.',
      'Toss lettuce with dressing until well coated.',
      'Top with croutons and remaining Parmesan.',
      'Serve immediately.'
    ],
    author: 'Julia Romano',
    createdAt: '2024-12-07'
  },
  {
    id: '5',
    title: 'Beef Tacos',
    description: 'Flavorful ground beef tacos with fresh toppings.',
    image: 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=800&q=80',
    prepTime: 10,
    cookTime: 15,
    servings: 6,
    difficulty: 'Easy',
    category: 'Mexican',
    ingredients: [
      '1 lb ground beef',
      '1 packet taco seasoning',
      '12 taco shells',
      '1 cup shredded lettuce',
      '1 cup diced tomatoes',
      '1 cup shredded cheese',
      '1/2 cup sour cream',
      '1/4 cup salsa'
    ],
    instructions: [
      'Brown ground beef in a large skillet over medium heat.',
      'Drain excess fat.',
      'Add taco seasoning and water according to package directions.',
      'Simmer for 5 minutes until thickened.',
      'Warm taco shells according to package directions.',
      'Fill shells with beef mixture.',
      'Top with lettuce, tomatoes, cheese, sour cream, and salsa.',
      'Serve immediately.'
    ],
    author: 'Carlos Martinez',
    createdAt: '2024-12-08'
  },
  {
    id: '6',
    title: 'Blueberry Pancakes',
    description: 'Fluffy pancakes loaded with fresh blueberries.',
    image: 'https://images.unsplash.com/photo-1506084868230-bb9d95c24759?w=800&q=80',
    prepTime: 10,
    cookTime: 15,
    servings: 4,
    difficulty: 'Easy',
    category: 'Breakfast',
    ingredients: [
      '2 cups all-purpose flour',
      '2 tbsp sugar',
      '2 tsp baking powder',
      '1/2 tsp salt',
      '2 eggs',
      '1 3/4 cups milk',
      '1/4 cup melted butter',
      '1 cup fresh blueberries',
      'Maple syrup for serving'
    ],
    instructions: [
      'Mix flour, sugar, baking powder, and salt in a large bowl.',
      'In another bowl, whisk eggs, milk, and melted butter.',
      'Pour wet ingredients into dry ingredients and mix until just combined.',
      'Gently fold in blueberries.',
      'Heat a griddle or pan over medium heat.',
      'Pour 1/4 cup batter for each pancake.',
      'Cook until bubbles form on surface, then flip.',
      'Cook until golden brown on both sides.',
      'Serve warm with maple syrup.'
    ],
    author: 'Emily Watson',
    createdAt: '2024-12-09'
  }
];

export function RecipeProvider({ children }: { children: ReactNode }) {
  const [recipes, setRecipes] = useState<Recipe[]>(initialRecipes);

  const addRecipe = (recipe: Omit<Recipe, 'id' | 'createdAt'>) => {
    const newRecipe: Recipe = {
      ...recipe,
      id: Date.now().toString(),
      createdAt: new Date().toISOString().split('T')[0]
    };
    setRecipes([newRecipe, ...recipes]);
  };

  const getRecipeById = (id: string) => {
    return recipes.find(recipe => recipe.id === id);
  };

  return (
    <RecipeContext.Provider value={{ recipes, addRecipe, getRecipeById }}>
      {children}
    </RecipeContext.Provider>
  );
}

export function useRecipes() {
  const context = useContext(RecipeContext);
  if (!context) {
    throw new Error('useRecipes must be used within RecipeProvider');
  }
  return context;
}
