import { Link } from 'react-router-dom';
import { Clock, Users, ChefHat } from 'lucide-react';
import { Recipe } from './RecipeContext';

interface RecipeCardProps {
  recipe: Recipe;
  featured?: boolean;
}

export function RecipeCard({ recipe, featured = false }: RecipeCardProps) {
  const totalTime = recipe.prepTime + recipe.cookTime;

  const difficultyColors = {
    Easy: 'bg-green-100 text-green-700',
    Medium: 'bg-yellow-100 text-yellow-700',
    Hard: 'bg-red-100 text-red-700'
  };

  return (
    <Link
      to={`/recipe/${recipe.id}`}
      className={`group bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-lg transition-shadow ${
        featured ? 'shadow-md' : ''
      }`}
    >
      <div className="relative overflow-hidden aspect-[4/3]">
        <img
          src={recipe.image}
          alt={recipe.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-3 right-3">
          <span className={`px-3 py-1 rounded-full text-sm ${difficultyColors[recipe.difficulty]}`}>
            {recipe.difficulty}
          </span>
        </div>
      </div>

      <div className="p-5">
        <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
          <span className="px-2 py-1 bg-orange-50 text-orange-600 rounded">
            {recipe.category}
          </span>
        </div>

        <h3 className="text-xl text-gray-900 mb-2 group-hover:text-orange-600 transition-colors">
          {recipe.title}
        </h3>

        <p className="text-gray-600 mb-4 line-clamp-2">
          {recipe.description}
        </p>

        <div className="flex items-center justify-between text-sm text-gray-500 pt-4 border-t border-gray-100">
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            <span>{totalTime} min</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="w-4 h-4" />
            <span>{recipe.servings} servings</span>
          </div>
          <div className="flex items-center gap-1">
            <ChefHat className="w-4 h-4" />
            <span className="truncate max-w-[100px]">{recipe.author}</span>
          </div>
        </div>
      </div>
    </Link>
  );
}
