import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { HomePage } from './components/HomePage';
import { RecipeDetail } from './components/RecipeDetail';
import { BrowseRecipes } from './components/BrowseRecipes';
import { AddRecipe } from './components/AddRecipe';
import { Navigation } from './components/Navigation';
import { RecipeProvider } from './components/RecipeContext';

export default function App() {
  return (
    <RecipeProvider>
      <Router>
        <div className="min-h-screen bg-gray-50">
          <Navigation />
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/browse" element={<BrowseRecipes />} />
            <Route path="/recipe/:id" element={<RecipeDetail />} />
            <Route path="/add" element={<AddRecipe />} />
          </Routes>
        </div>
      </Router>
    </RecipeProvider>
  );
}
